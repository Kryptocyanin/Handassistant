import logging
import json
import asyncio
from functools import wraps
from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
from flask_login import login_required, current_user
from utils.chatbot import MedicalChatbot
from utils.translation import Translator

logger = logging.getLogger(__name__)

# Create a blueprint for chat routes
chat_bp = Blueprint('chat', __name__)

# Initialize chatbot and translator
chatbot = MedicalChatbot()
translator = Translator()

# Custom decorator to ensure user has registered hand data
def hand_verification_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.hand_data:
            flash('You must register your hand for biometric authentication before accessing this feature.', 'warning')
            return redirect(url_for('auth.hand_registration'))
        return f(*args, **kwargs)
    return decorated_function

@chat_bp.route('/chat')
@login_required
@hand_verification_required
def index():
    """Render the chat interface"""
    return render_template('chat.html')

@chat_bp.route('/api/chat', methods=['POST'])
@login_required
@hand_verification_required
def process_message():
    """Process chat message and return response"""
    try:
        data = request.json
        message = data.get('message')
        
        if not message:
            return jsonify({'error': 'No message provided'}), 400
        
        # Get current user's ID for conversation memory
        user_id = str(current_user.id)
        
        # Generate response using Groq API with conversation memory - convert async to sync
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        response, patient_data = loop.run_until_complete(chatbot.generate_response(message, user_id))
        loop.close()
        
        # Build response JSON
        response_data = {
            'response': response
        }
        
        # If patient data was found, include it in the response
        if patient_data:
            response_data['patient_data'] = patient_data
        
        logger.debug(f"Processed message: '{message[:30]}...'")
        return jsonify(response_data)
    
    except Exception as e:
        logger.error(f"Error processing message: {str(e)}")
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/api/translate', methods=['POST'])
@login_required
@hand_verification_required
def translate_text():
    """Translate text to the target language"""
    try:
        data = request.json
        text = data.get('text')
        target_language = data.get('target_language')
        
        if not text or not target_language:
            return jsonify({'error': 'Text and target language are required'}), 400
        
        # Get current user's ID for conversation context
        user_id = str(current_user.id)
        
        # Check if the text is the last response from chatbot history
        last_assistant_response = None
        if user_id in chatbot.conversation_history:
            user_history = chatbot.conversation_history[user_id]
            messages = user_history.get("messages", [])
            
            # Find the last assistant message
            for msg in reversed(messages):
                if msg.get("role") == "assistant":
                    last_assistant_response = msg.get("content")
                    break
        
        # If the text doesn't match the last response, use direct translation
        # Otherwise, preserve context and use chatbot translation
        if last_assistant_response != text:
            # Direct translation - convert async to sync
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            translated_text = loop.run_until_complete(translator.translate_text(text, target_language))
            loop.close()
        else:
            # Use chatbot with context for translation
            translation_prompt = f"translate to {target_language}"
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            translated_text, _ = loop.run_until_complete(chatbot.generate_response(translation_prompt, user_id))
            loop.close()
        
        logger.debug(f"Translated text to {target_language}")
        return jsonify({
            'original_text': text,
            'translated_text': translated_text,
            'target_language': target_language
        })
    
    except Exception as e:
        logger.error(f"Error translating text: {str(e)}")
        return jsonify({'error': str(e)}), 500
