import json
import logging
from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from models import User, HandData
from utils.hand_recognition import HandRecognition

logger = logging.getLogger(__name__)

# Create a blueprint for authentication routes
auth_bp = Blueprint('auth', __name__)

# Initialize hand recognition utility
hand_recognizer = HandRecognition()

@auth_bp.route('/test-hands')
def test_hands():
    """Test page for MediaPipe Hands"""
    return redirect('/static/test-hands.html')

@auth_bp.route('/')
def index():
    """Redirect to login if not authenticated, or chat if authenticated"""
    if current_user.is_authenticated:
        return redirect(url_for('chat.index'))
    return redirect(url_for('auth.login'))

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Handle user login"""
    if current_user.is_authenticated:
        return redirect(url_for('chat.index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            # If user has hand data, proceed to hand verification
            if user.hand_data:
                # Store user_id in session for hand verification
                session['verification_user_id'] = user.id
                logger.debug(f"Login successful for user {username}, proceeding to hand verification")
                return redirect(url_for('auth.hand_verification'))
            
            # If no hand data, proceed to hand registration
            # Only store the user_id in session, don't login yet
            session['registration_user_id'] = user.id
            logger.info(f"User {username} needs to register hand data")
            flash('You need to register your hand for authentication', 'warning')
            return redirect(url_for('auth.hand_registration'))
        
        flash('Invalid username or password', 'danger')
        logger.warning(f"Failed login attempt for username: {username}")
    
    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Handle user registration"""
    if current_user.is_authenticated:
        return redirect(url_for('chat.index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate input
        if not username or not email or not password:
            flash('All fields are required', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html')
        
        # Check if username or email already exists
        existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
        if existing_user:
            flash('Username or email already exists', 'danger')
            return render_template('register.html')
        
        # Create new user
        new_user = User(username=username, email=email)
        new_user.set_password(password)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            
            # Store user ID in session for hand registration
            session['registration_user_id'] = new_user.id
            
            logger.info(f"User {username} registered successfully")
            flash('Registration successful! Please register your hand for authentication', 'success')
            return redirect(url_for('auth.hand_registration'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error during user registration: {str(e)}")
            flash('An error occurred during registration', 'danger')
    
    return render_template('register.html')

@auth_bp.route('/hand-registration', methods=['GET', 'POST'])
def hand_registration():
    """Handle hand registration for biometric authentication"""
    # Get user_id from session for new users or use current_user for logged in users
    user_id = session.get('registration_user_id')
    
    # If no user_id in session and not logged in, redirect to login
    if not user_id and not current_user.is_authenticated:
        flash('Session expired, please log in again', 'danger')
        return redirect(url_for('auth.login'))
    
    # Get the user object
    if current_user.is_authenticated:
        user = current_user
    else:
        user = User.query.get(user_id)
        if not user:
            flash('User not found, please log in again', 'danger')
            return redirect(url_for('auth.login'))
    
    if request.method == 'POST':
        hand_data = request.form.get('hand_data')
        
        if not hand_data:
            flash('No hand data received', 'danger')
            return render_template('hand_registration.html')
        
        # Validate hand data format
        if not hand_recognizer.validate_landmarks(hand_data):
            flash('Invalid hand data format', 'danger')
            return render_template('hand_registration.html')
        
        try:
            # Check if user already has hand data
            if user.hand_data:
                # Update existing hand data
                user.hand_data.hand_landmarks = hand_data
            else:
                # Create new hand data
                new_hand_data = HandData(user_id=user.id, hand_landmarks=hand_data)
                db.session.add(new_hand_data)
            
            db.session.commit()
            logger.info(f"Hand registration successful for user {user.username}")
            
            # If user came from login (not already authenticated), log them in and clear session
            if not current_user.is_authenticated and user_id:
                login_user(user)
                session.pop('registration_user_id', None)
            
            flash('Hand registration successful! You can now access the chat', 'success')
            return redirect(url_for('chat.index'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error during hand registration: {str(e)}")
            flash('An error occurred during hand registration', 'danger')
    
    return render_template('hand_registration.html')

@auth_bp.route('/hand-verification', methods=['GET', 'POST'])
def hand_verification():
    """Handle hand verification for biometric authentication"""
    # Get user_id from session
    user_id = session.get('verification_user_id')
    if not user_id:
        flash('Session expired, please log in again', 'danger')
        return redirect(url_for('auth.login'))
    
    user = User.query.get(user_id)
    if not user or not user.hand_data:
        flash('User not found or no hand data available', 'danger')
        return redirect(url_for('auth.login'))
    
    if request.method == 'POST':
        # Hand verification was successful, log in the user
        login_user(user)
        # Clear the verification session
        session.pop('verification_user_id', None)
        logger.info(f"Hand verification successful for user {user.username}")
        flash('Authentication successful!', 'success')
        return redirect(url_for('chat.index'))
    
    # Pass stored hand data to the template (directly use the JSON string)
    return render_template('hand_verification.html', hand_data=user.hand_data.hand_landmarks)

@auth_bp.route('/verify-hand', methods=['POST'])
def verify_hand():
    """API endpoint to verify hand data"""
    # Get user_id from session
    user_id = session.get('verification_user_id')
    if not user_id:
        flash('Session expired, please log in again', 'danger')
        return redirect(url_for('auth.login'))
    
    # Get the current hand landmarks from the form
    current_hand_data = request.form.get('hand_data')
    if not current_hand_data:
        flash('No hand data received', 'danger')
        return redirect(url_for('auth.hand_verification'))
    
    # Validate the current hand landmarks
    if not hand_recognizer.validate_landmarks(current_hand_data):
        flash('Invalid hand data format', 'danger')
        return redirect(url_for('auth.hand_verification'))
    
    # Get user and stored hand data
    user = User.query.get(user_id)
    if not user or not user.hand_data:
        flash('User not found or no hand data available', 'danger')
        return redirect(url_for('auth.login'))
    
    # Compare hand landmarks
    stored_landmarks = user.hand_data.hand_landmarks
    is_match = hand_recognizer.is_match(stored_landmarks, current_hand_data)
    
    if not is_match:
        flash('Hand verification failed. Please try again.', 'danger')
        return redirect(url_for('auth.hand_verification'))
    
    # Log in user after successful verification
    login_user(user)
    # Clear the verification session
    session.pop('verification_user_id', None)
    logger.info(f"Hand verification successful for user {user.username}")
    flash('Authentication successful!', 'success')
    return redirect(url_for('chat.index'))

@auth_bp.route('/logout')
@login_required
def logout():
    """Handle user logout"""
    username = current_user.username
    logout_user()
    logger.info(f"User {username} logged out")
    flash('You have been logged out', 'info')
    return redirect(url_for('auth.login'))
