import groq
import logging
import re
from typing import Optional, Tuple
from config import Config

logger = logging.getLogger(__name__)

class Translator:
    """
    Utility class for translating text and detecting languages using the Groq API
    """
    
    def __init__(self):
        """Initialize translator with Groq API client"""
        self.api_key = Config.GROQ_API_KEY
        self.client = groq.Client(api_key=self.api_key)
        self.model = Config.CHAT_MODEL
        logger.debug("Translator initialized")
        
        # Cache for language detection to avoid repeated API calls
        self.language_cache = {}
    
    async def detect_language(self, text: str) -> Tuple[str, str]:
        """
        Detect the language of the input text
        
        Args:
            text: Text to detect language for
            
        Returns:
            Tuple[str, str]: (language_code, language_name)
        """
        # Check cache first
        if text[:100] in self.language_cache:
            return self.language_cache[text[:100]]
            
        try:
            # Use a small model request to detect the language
            system_prompt = "You are a language detection tool. Detect the language of the following text. Return only the language code (like 'en', 'es', 'fr', 'hi', 'zh') followed by a colon and the full language name. Example: 'en: English' or 'hi: Hindi'"
            
            chat_completion = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text}
                ],
                temperature=0.1,
                max_tokens=20,
            )
            
            # Extract the response
            detection_result = chat_completion.choices[0].message.content.strip()
            
            # Parse the result - expected format: "xx: Language Name"
            match = re.match(r'([a-z]{2}):\s*(.+)', detection_result, re.IGNORECASE)
            if match:
                language_code = match.group(1).lower()
                language_name = match.group(2).strip()
                
                # Cache the result
                self.language_cache[text[:100]] = (language_code, language_name)
                
                logger.debug(f"Detected language: {language_name} ({language_code})")
                return language_code, language_name
            else:
                logger.warning(f"Failed to parse language detection result: {detection_result}")
                return "en", "English"  # Default to English if parsing fails
                
        except Exception as e:
            logger.error(f"Error detecting language: {str(e)}")
            return "en", "English"  # Default to English on error
    
    async def translate_text(self, text: str, target_language: str) -> str:
        """
        Translate text to the target language
        
        Args:
            text: Text to translate
            target_language: Target language for translation
            
        Returns:
            str: Translated text
        """
        try:
            # Create a system prompt for translation
            system_prompt = f"You are a translator. Translate the following text to {target_language} accurately and fluently. Only return the translated text without any explanations or additional text."
            
            # Create the chat completion request
            chat_completion = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text}
                ],
                temperature=0.3,
                max_tokens=1024,
            )
            
            # Extract the response text
            translated_text = chat_completion.choices[0].message.content
            
            logger.debug(f"Translated text to {target_language}")
            return translated_text
            
        except Exception as e:
            logger.error(f"Error translating text: {str(e)}")
            return f"Translation error: {str(e)}"
            
    # Helper function to extract translation commands from text
    def extract_translation_command(self, text: str) -> Optional[str]:
        """
        Extract translation command from text
        
        Args:
            text: Text to check for translation commands
            
        Returns:
            Optional[str]: Target language if found, None otherwise
        """
        # Enhanced pattern recognition for translation commands
        patterns = [
            # Standard pattern: translate [this] to <language>
            r'translate\s+(?:this\s+)?(?:to\s+)?(\w+)',
            
            # Direct language mention: in <language> please/thanks
            r'(?:in|into|to)\s+(\w+)(?:\s+(?:please|pls|language|tongue|translation))',
            
            # Command variants: show/tell/say [this] in <language>
            r'(?:show|tell|say|write|display|convert)(?:\s+this)?\s+(?:in|into|to)\s+(\w+)',
            
            # Question forms: can/could you translate [this] to <language>
            r'(?:can|could|would|will|please)\s+(?:you\s+)?translate(?:\s+this)?\s+(?:to|into)\s+(\w+)',
            
            # Explicit language request: <language> translation please/needed
            r'(\w+)\s+(?:translation|version|language)\s+(?:please|needed|required)'
        ]
        
        # Check each pattern
        text_lower = text.lower()
        for pattern in patterns:
            match = re.search(pattern, text_lower)
            if match:
                language = match.group(1).lower()
                
                # Normalize some common language names
                language_mapping = {
                    # Spanish variants
                    'spanish': 'spanish', 'español': 'spanish', 'espanol': 'spanish',
                    # French variants
                    'french': 'french', 'français': 'french', 'francais': 'french',
                    # German variants
                    'german': 'german', 'deutsch': 'german',
                    # Chinese variants
                    'chinese': 'chinese', 'mandarin': 'chinese', '中文': 'chinese',
                    # Japanese variants
                    'japanese': 'japanese', '日本語': 'japanese',
                    # Hindi variants
                    'hindi': 'hindi', 'हिन्दी': 'hindi',
                    # Arabic variants
                    'arabic': 'arabic', 'العربية': 'arabic',
                    # Russian variants
                    'russian': 'russian', 'русский': 'russian',
                    # Portuguese variants
                    'portuguese': 'portuguese', 'português': 'portuguese', 'portugues': 'portuguese',
                    # Italian variants
                    'italian': 'italian', 'italiano': 'italian',
                    # Dutch variants
                    'dutch': 'dutch', 'nederlands': 'dutch',
                    # Common abbreviations
                    'en': 'english', 'eng': 'english',
                    'es': 'spanish', 'sp': 'spanish',
                    'fr': 'french',
                    'de': 'german',
                    'zh': 'chinese', 'cn': 'chinese',
                    'ja': 'japanese', 'jp': 'japanese',
                    'hi': 'hindi',
                    'ar': 'arabic',
                    'ru': 'russian',
                    'pt': 'portuguese',
                    'it': 'italian',
                    'nl': 'dutch'
                }
                
                # Return normalized language name if found, otherwise the original
                return language_mapping.get(language, language)
        
        return None
