import numpy as np
import json
import logging
from typing import List, Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)

class HandRecognition:
    """
    Utility class for handling hand landmark data processing and comparison
    """
    
    def __init__(self, similarity_threshold: float = 0.85):
        """
        Initialize the hand recognition utility
        
        Args:
            similarity_threshold: Float value between 0 and 1 for determining match threshold
        """
        self.similarity_threshold = similarity_threshold
        logger.debug(f"HandRecognition initialized with threshold: {similarity_threshold}")
    
    def validate_landmarks(self, landmarks_json: str) -> bool:
        """
        Validate that the landmarks JSON is correctly formatted
        
        Args:
            landmarks_json: JSON string of hand landmarks
            
        Returns:
            bool: True if landmarks are valid, False otherwise
        """
        try:
            landmarks = json.loads(landmarks_json)
            
            # Check if landmarks are a list
            if not isinstance(landmarks, list):
                logger.warning("Landmarks are not a list")
                return False
            
            # MediaPipe hand landmarks should have 21 points
            if len(landmarks) != 21:
                logger.warning(f"Expected 21 landmarks, got {len(landmarks)}")
                return False
                
            # Check if each landmark has x, y, z coordinates
            for point in landmarks:
                if not all(k in point for k in ['x', 'y', 'z']):
                    logger.warning("Landmark missing coordinates")
                    return False
            
            return True
        except json.JSONDecodeError:
            logger.warning("Invalid JSON format for landmarks")
            return False
        except Exception as e:
            logger.error(f"Error validating landmarks: {str(e)}")
            return False
    
    def compare_landmarks(self, stored_landmarks_json: str, current_landmarks_json: str) -> float:
        """
        Compare stored hand landmarks with current landmarks
        
        Args:
            stored_landmarks_json: JSON string of stored hand landmarks
            current_landmarks_json: JSON string of current hand landmarks
            
        Returns:
            float: Similarity score between 0 and 1
        """
        try:
            # Parse JSON strings
            stored_landmarks = json.loads(stored_landmarks_json)
            current_landmarks = json.loads(current_landmarks_json)
            
            # Check if both have 21 landmarks (MediaPipe hand landmarks)
            if len(stored_landmarks) != 21 or len(current_landmarks) != 21:
                logger.warning("Landmark sets have different lengths")
                return 0.0
            
            # Calculate Euclidean distances between corresponding landmarks
            total_distance = 0.0
            for i in range(21):
                stored_point = stored_landmarks[i]
                current_point = current_landmarks[i]
                
                distance = np.sqrt(
                    (stored_point['x'] - current_point['x']) ** 2 +
                    (stored_point['y'] - current_point['y']) ** 2 +
                    (stored_point['z'] - current_point['z']) ** 2
                )
                total_distance += distance
            
            # Calculate average distance and convert to similarity score
            avg_distance = total_distance / 21
            
            # Scale factor to convert distance to similarity (0-1)
            # The scaling factor (10) is based on empirical testing
            similarity = max(0, 1 - avg_distance * 10)
            
            logger.debug(f"Hand similarity score: {similarity:.4f}")
            return similarity
            
        except Exception as e:
            logger.error(f"Error comparing landmarks: {str(e)}")
            return 0.0
    
    def is_match(self, stored_landmarks_json: str, current_landmarks_json: str) -> bool:
        """
        Determine if the hand landmarks match based on the similarity threshold
        
        Args:
            stored_landmarks_json: JSON string of stored hand landmarks
            current_landmarks_json: JSON string of current hand landmarks
            
        Returns:
            bool: True if the hands match, False otherwise
        """
        similarity = self.compare_landmarks(stored_landmarks_json, current_landmarks_json)
        return similarity >= self.similarity_threshold
