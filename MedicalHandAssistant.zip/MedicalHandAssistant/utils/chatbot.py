import groq
import os
import json
import logging
import re
import sys
from typing import Dict, List, Any, Tuple, Optional
from config import Config
from utils.translation import Translator
import anthropic

logger = logging.getLogger(__name__)

class MedicalChatbot:
    """
    Utility class for interacting with the Groq API or Anthropic API for medical chatbot functionality
    """
    
    def __init__(self):
        """Initialize the medical chatbot with Groq and Anthropic API clients"""
        # Groq configuration
        self.groq_api_key = Config.GROQ_API_KEY
        self.groq_client = groq.Client(api_key=self.groq_api_key)
        self.groq_model = Config.CHAT_MODEL
        
        # Anthropic configuration
        self.anthropic_api_key = Config.ANTHROPIC_API_KEY
        self.anthropic_model = Config.ANTHROPIC_MODEL
        if self.anthropic_api_key:
            self.anthropic_client = anthropic.Anthropic(api_key=self.anthropic_api_key)
        else:
            self.anthropic_client = None
        
        # Model provider selection
        self.model_provider = Config.MODEL_PROVIDER
        
        # Initialize patient records
        self.patient_records = []
        
        # Initialize conversation memory and translator
        self.conversation_history = {}  # User ID -> list of previous exchanges
        self.translator = Translator()  # For language detection and translation
        
        # Log initialization
        if self.model_provider == "anthropic" and not self.anthropic_api_key:
            logger.warning("Anthropic API key not found. Falling back to Groq.")
            self.model_provider = "groq"
            
        logger.debug(f"MedicalChatbot initialized with provider: {self.model_provider}")
        
        # Load sample patient records
        for patient_data in Config.SAMPLE_PATIENTS:
            self.patient_records.append(patient_data)
    
    def _create_system_prompt(self, language_code: str = "en", language_name: str = "English") -> str:
        """
        Create a system prompt for the chatbot model, customized for the detected language
        
        Args:
            language_code: The ISO language code (e.g., 'en', 'es', 'fr', 'hi')
            language_name: The full name of the language (e.g., 'English', 'Spanish')
            
        Returns:
            str: The system prompt
        """
        # Enhanced system prompt with more detailed instructions for Claude
        system_prompt = """
        You are an advanced multilingual medical assistant with a sophisticated understanding of healthcare and medical science. 
        Your purpose is to provide detailed, evidence-based medical information while intelligently retrieving and analyzing patient data.
        
        CAPABILITIES:
        1. ENHANCED MEDICAL REASONING: Provide comprehensive, scientifically accurate responses to complex medical questions, incorporating the latest research and medical guidelines
        2. INTELLIGENT PATIENT DATA ANALYSIS: Precisely identify and analyze patient information through sophisticated pattern recognition, offering clinically relevant insights
        3. CONTEXTUAL MEMORY: Maintain awareness of conversation history to provide consistent, contextually appropriate responses that build on previous exchanges
        4. MULTILINGUAL EXPERTISE: Communicate fluently in multiple languages while maintaining medical accuracy and cultural sensitivity
        5. MEDICAL KEYWORD ANALYSIS: Identify and explain specialized medical terminology with academic precision
        6. PERSONALIZED CLINICAL RECOMMENDATIONS: Suggest evidence-based treatments and management strategies tailored to specific patient profiles
        7. DIFFERENTIAL DIAGNOSTIC THINKING: Consider multiple diagnostic possibilities when presented with symptoms or conditions
        8. ADAPTIVE COMMUNICATION: Adjust your communication style based on the complexity of questions and user preferences
        
        PATIENT DATA RETRIEVAL:
        - Recognize patient identifiers including name, ID, age, gender, or condition
        - Integrate patient information across multiple conversational turns
        - Remember previously discussed patient data to maintain continuity
        - Present patient information in a structured, clinically meaningful format
        - Flag important clinical considerations based on patient details
        
        RESPONSE GUIDELINES:
        - Prioritize clinical relevance and accuracy above all else
        - Structure responses with clear organization, emphasizing key points
        - Include specific, actionable recommendations where appropriate
        - Maintain professional medical tone with appropriate empathy
        - Acknowledge limitations and recommend appropriate healthcare providers when necessary
        - Provide context for medical recommendations, explaining the reasoning behind them
        - When uncertain, be transparent rather than speculative
        
        The information you provide should be medically precise while remaining accessible to individuals with varying levels of medical knowledge.
        """
        
        # If the language is not English, add enhanced instructions to respond in the detected language
        if language_code != "en":
            language_instruction = f"""
            
            LANGUAGE INSTRUCTIONS:
            - The user is communicating in {language_name}. You must respond in {language_name} unless explicitly asked to translate.
            - Maintain the same level of clinical accuracy and precision in {language_name} as you would in English.
            - Use appropriate medical terminology in {language_name}, considering regional variations in medical vocabulary.
            - Ensure your explanations remain clear and accessible to {language_name} speakers with different levels of medical knowledge.
            - Adapt idiomatic expressions and cultural references to be appropriate for {language_name}-speaking contexts.
            - When discussing treatments, consider regional availability of medications and healthcare resources.
            """
            system_prompt += language_instruction
        
        return system_prompt
    
    def _get_additional_context(self, message: str, patient_data: Optional[Dict[str, Any]]) -> Optional[str]:
        """
        Generate additional context for the chatbot based on the message and patient data
        
        Args:
            message: User's message
            patient_data: Patient data if found
            
        Returns:
            Optional[str]: Additional context for the chatbot
        """
        # Initialize context
        context_parts = []
        
        # Add enhanced context about detected medical terminology
        medical_terms = self._detect_medical_terminology(message)
        if medical_terms:
            terms_str = ', '.join(medical_terms)
            context_parts.append(f"""
MEDICAL TERMINOLOGY ANALYSIS:
The user's message contains the following medical terms: {terms_str}. 
For each term:
1. Provide a concise clinical definition
2. Explain its significance in a medical context
3. Discuss relevant diagnostic considerations or treatment approaches
4. Connect it to other related medical concepts when appropriate
5. If the terms appear related, analyze possible connections between them
            """)
        
        # Add enhanced context if the message appears to be asking about medical advice
        if self._is_seeking_medical_advice(message):
            context_parts.append("""
MEDICAL ADVICE REQUEST DETECTED:
The user appears to be seeking clinical guidance. In your response:
1. Structure information with clear clinical reasoning
2. Provide evidence-based information with references to current guidelines when possible
3. Present a balanced view of treatment options with their respective benefits and limitations
4. Include specific, actionable recommendations while emphasizing that this doesn't replace professional medical consultation
5. Address potential contraindications, warning signs, or when to seek emergency care
6. Suggest specific types of healthcare professionals who would be appropriate for consultation
            """)
        
        # Add enhanced context if this is a patient query
        if patient_data:
            # Create a detailed patient summary for the model
            patient_summary = f"""
PATIENT PROFILE:
- NAME: {patient_data['name']}
- ID: {patient_data['patient_id']}
- AGE: {patient_data['age']}
- GENDER: {patient_data['gender']}
- PRIMARY CONDITION: {patient_data['condition']}
- TREATMENT PLAN: {patient_data['treatment']}
- MEDICATIONS: {patient_data['medications']}
- CLINICAL NOTES: {patient_data['notes']}
- FINANCIAL: Bill amount ${patient_data['bill_amount']}

CLINICAL ANALYSIS INSTRUCTIONS:
1. Analyze how the patient's age, gender, and condition may interact
2. Consider possible medication interactions or side effects
3. Identify key clinical monitoring parameters based on their condition and medications
4. Assess whether the current treatment plan aligns with evidence-based guidelines
5. Consider potential comorbidities or complications associated with their primary condition
6. Provide personalized recommendations specific to this patient's clinical profile
7. Highlight any areas that might need additional clinical attention
8. Frame all information in a manner that preserves patient dignity and confidentiality
            """
            context_parts.append(patient_summary)
        
        # Enhanced detection for translation requests using the translator utility
        target_language = self.translator.extract_translation_command(message)
        if target_language:
            context_parts.append(f"""
TRANSLATION REQUEST DETECTED:
The user is requesting translation to {target_language}. In your response:
1. Translate all medical terminology accurately using proper {target_language} medical vocabulary
2. Maintain the same level of clinical precision in the translation
3. Consider cultural context and regional variations in {target_language} medical terminology
4. Preserve the structure and organization of the medical information
5. Ensure dosages, measurements, and other numerical information remain accurate
6. Include special formatting to indicate key terms if they have direct medical equivalents in {target_language}
7. If certain terms don't have direct translations, provide the original term in parentheses after your best translation
            """)
        
        # Add context for maintaining conversational continuity
        context_parts.append("""
CONVERSATION CONTINUITY GUIDELINES:
1. Reference information from previous exchanges when relevant
2. Build upon previously established clinical context
3. If contradicting previous information, explicitly acknowledge the update
4. Maintain consistency in clinical recommendations across the conversation
5. Adapt tone and complexity based on the user's demonstrated knowledge level
        """)
        
        # Return combined context if we have any
        if context_parts:
            return "\n\n".join(context_parts)
        return None
    
    def _detect_medical_terminology(self, message: str) -> List[str]:
        """
        Detect medical terminology in the message
        
        Args:
            message: User's message
            
        Returns:
            List[str]: List of detected medical terms
        """
        # Expanded list of medical terms for more comprehensive detection
        medical_terms = [
            # Common conditions
            "hypertension", "diabetes", "arthritis", "asthma", "depression", "anxiety", 
            "hypothyroidism", "hyperthyroidism", "pneumonia", "bronchitis", "emphysema",
            "alzheimer", "dementia", "parkinson", "schizophrenia", "bipolar", "fibromyalgia",
            "migraine", "epilepsy", "seizure", "stroke", "heart attack", "myocardial infarction",
            "osteoporosis", "gerd", "ibs", "crohn", "ulcerative colitis", "multiple sclerosis",
            "lupus", "rheumatoid", "psoriasis", "eczema", "dermatitis", "cancer",
            
            # Medical specialties
            "cardiology", "cardiovascular", "oncology", "neurology", "pulmonary", "gastroenterology",
            "orthopedic", "nephrology", "endocrinology", "urology", "immunology", "hematology",
            "psychiatry", "ophthalmology", "dermatology", "obstetrics", "gynecology", "pediatrics",
            
            # Medications and treatments
            "antibiotics", "analgesics", "anti-inflammatory", "insulin", "vaccine", "statin",
            "beta blocker", "ace inhibitor", "anticoagulant", "antidepressant", "diuretic",
            "steroid", "bronchodilator", "inhaler", "antipsychotic", "chemotherapy", "radiation",
            "antihistamine", "immunosuppressant", "nsaid", "opioid", "benzodiazepine",
            
            # Medical tests and procedures
            "biopsy", "mri", "ct scan", "ultrasound", "x-ray", "ecg", "ekg", "eeg",
            "colonoscopy", "endoscopy", "stress test", "angiogram", "blood test", "urinalysis",
            "mammogram", "pap smear", "biopsy", "defibrillation", "intubation", "cardioversion",
            
            # Clinical terms
            "diagnosis", "prognosis", "symptoms", "chronic", "acute", "remission", "relapse",
            "pathology", "etiology", "comorbidity", "differential", "idiopathic", "iatrogenic",
            "congenital", "hereditary", "syndrome", "palliative", "preventive", "trauma",
            "triage", "vital signs", "infection", "inflammation", "cyst", "tumor", "lesion",
            
            # Anatomical terms
            "cerebral", "cardiac", "pulmonary", "hepatic", "renal", "vascular", "muscular",
            "skeletal", "neurological", "gastrointestinal", "respiratory", "endocrine",
            "hematological", "lymphatic", "immune", "reproductive", "urinary", "integumentary"
        ]
        
        # Convert message to lowercase for case-insensitive matching
        message_lower = message.lower()
        
        # Find all medical terms in the message with improved pattern matching
        found_terms = []
        for term in medical_terms:
            # Use word boundary for more accurate matching
            if re.search(r'\b' + re.escape(term) + r'\b', message_lower):
                found_terms.append(term)
        
        return found_terms
    
    def _is_seeking_medical_advice(self, message: str) -> bool:
        """
        Determine if the message is seeking medical advice
        
        Args:
            message: User's message
            
        Returns:
            bool: True if seeking medical advice, False otherwise
        """
        # Expanded patterns that indicate seeking medical advice
        advice_patterns = [
            # Treatment questions
            r'\bhow (?:to|do|can|should) (?:treat|cure|manage|handle|deal with|address|cope with|relieve|reduce|alleviate)\b',
            r'\bwhat (?:should|can|do|could|might|would) (?:I|you|one|we|someone|a person) (?:do|take|use|try|consider|recommend) for\b',
            r'\b(?:best|effective|recommended|appropriate) (?:treatment|therapy|medication|remedy|medicine|approach|option|course of action)\b',
            
            # Symptom inquiries
            r'\b(?:symptoms|signs|indications|markers|manifestations|characteristics) of\b',
            r'\b(?:what|how) (?:does|do|would|might) (?:it|this|that|the condition|the disease|the illness) (?:feel|look|present|appear|manifest)\b',
            r'\bis (?:this|that|it) (?:a sign|a symptom|an indication|normal|typical|expected)\b',
            
            # Causes and risk factors
            r'\bcauses? of\b',
            r'\b(?:what|which) (?:causes|contributes to|leads to|results in|triggers|factors|risks)\b',
            r'\b(?:why|how) (?:does|do|would) (?:someone|a person|people|patients) (?:get|develop|contract|acquire)\b',
            r'\b(?:am|are|is) (?:I|you|they|we|one) (?:at risk|susceptible|vulnerable|prone|likely) to\b',
            
            # Evaluation of severity
            r'\b(?:is|are|could|should|would) (?:it|this|that|these symptoms|this condition) (?:normal|serious|dangerous|concerning|worrying|critical|life-threatening|urgent|emergency|significant)\b',
            r'\b(?:how|when) (?:serious|dangerous|concerning|severe|bad|critical|urgent|emergent) is\b',
            r'\b(?:need|should|must) (?:I|one|someone) (?:worry|be concerned|be alarmed|panic|seek help|get treatment)\b',
            
            # Professional consultation questions
            r'\bshould (?:I|one|someone|a person) (?:see|visit|consult|talk to|go to|meet with|speak with) (?:a|the) (?:doctor|physician|specialist|healthcare provider|medical professional|GP|PCP|professional|clinician|practitioner)\b',
            r'\bwhen (?:to|should|do I) (?:see|seek|get|consult|visit) (?:a|the) (?:doctor|emergency room|urgent care|hospital|clinic|specialist)\b',
            
            # Medication and treatment details
            r'\b(?:recommended|suggested|appropriate|proper|typical|standard|common|usual) (?:treatment|dosage|dose|prescription|therapy|regimen|protocol)\b',
            r'\bside effects\b',
            r'\b(?:how|when) (?:to|should|do I) (?:take|use|administer|apply|consume|inject)\b',
            r'\bhow (?:much|often|long|frequently)\b',
            r'\bdosage\b',
            r'\bmedication for\b',
            
            # Prognosis and outcomes
            r'\bhow long (?:does|will|would|should|could|might) (?:it|this|that|recovery|healing|treatment) (?:take|last|continue|persist|remain)\b',
            r'\b(?:what|how) (?:is|are|will be) (?:the|my|their) (?:chances|prognosis|outlook|recovery|outcome|future|prospects)\b',
            r'\b(?:will|can|could) (?:I|one|they|someone|a person) (?:recover|heal|get better|improve|survive)\b',
            
            # Prevention questions
            r'\bhow (?:to|do I|can I|should I|could I) (?:prevent|avoid|reduce the risk of|minimize|stop|protect against)\b',
            r'\b(?:what|which) (?:preventive|preventative|prophylactic) (?:measures|steps|actions|treatments|medications)\b'
        ]
        
        # Check if any pattern matches
        message_lower = message.lower()
        for pattern in advice_patterns:
            if re.search(pattern, message_lower):
                return True
        
        return False
    
    def _detect_patient_query(self, message: str) -> Optional[Dict[str, Any]]:
        """
        Detect if the message is asking for patient information
        
        Args:
            message: User's message
            
        Returns:
            Optional[Dict]: Patient record if found, None otherwise
        """
        # Convert message to lowercase for case-insensitive matching
        message_lower = message.lower()
        
        # Enhanced patient query indicators with more comprehensive patterns
        patient_query_indicators = [
            # Direct mentions of patient-related terms
            "patient", "record", "information", "details", "data", "profile", 
            "medical history", "chart", "case", "file", "report",
            
            # Action phrases for retrieving patient info
            "show me", "tell me about", "find patient", "lookup patient", "retrieve", "access",
            "get info", "pull up", "bring up", "search for", "look for", "locate",
            
            # Patient ID indicators
            "patient id", "patient #", "patient number", "id number", "identifier", "medical record number",
            "p001", "p002", "p003", "p004",  # Sample patient IDs
            
            # Query phrases
            "who is the patient", "what about the patient", "do you have info on", 
            "can you show", "can you find", "can you tell me about", "what do you know about",
            "is there a patient", "patient with", "patient named", "their medical record"
        ]
        
        # First check for explicit mentions
        is_patient_query = any(indicator in message_lower for indicator in patient_query_indicators)
        
        # If no explicit mention, check for name patterns that might indicate patient queries
        if not is_patient_query:
            # Check for common ways people might ask about patients by name
            name_query_patterns = [
                r'\b(?:mr|mrs|ms|miss|dr)\.?\s+\w+\b',  # Title followed by name
                r'\bpatient\s+\w+\b',  # "patient" followed by name
                r'\b(?:person|individual)\s+(?:named|called)\s+\w+\b',  # Person named/called X
                r'\b(?:what|who|how) is\s+\w+(?:\s+\w+)?\b',  # What/who/how is [Name]
                r'\btell me about\s+\w+(?:\s+\w+)?\b'  # Tell me about [Name]
            ]
            
            for pattern in name_query_patterns:
                if re.search(pattern, message_lower):
                    is_patient_query = True
                    break
        
        if not is_patient_query:
            return None
        
        # Look for patient identifiers in the message with intelligent matching
        matched_patients = []
        match_scores = []
        
        for patient in self.patient_records:
            score = 0
            
            # Check for patient ID - exact match gets high score
            if patient["patient_id"].lower() in message_lower:
                score += 10
            
            # Check for patient name with partial matching
            name_parts = patient["name"].lower().split()
            name_matches = sum(1 for part in name_parts if part in message_lower)
            if name_matches > 0:
                # Give higher score for more name parts matched
                score += name_matches * 3
                # Bonus if full name is matched
                if name_matches == len(name_parts):
                    score += 5
            
            # Check for age - exact match
            age_pattern = r'\b' + str(patient["age"]) + r'\b'
            if re.search(age_pattern, message_lower):
                score += 3
                # Bonus for age + gender combination
                if patient["gender"].lower() in message_lower:
                    score += 2
            
            # Check for gender
            if patient["gender"].lower() in message_lower:
                score += 2
            
            # Check for medical condition - partial matching
            condition_parts = patient["condition"].lower().split()
            condition_matches = sum(1 for part in condition_parts if part in message_lower)
            if condition_matches > 0:
                score += condition_matches * 2
            
            # Check for treatment mentions
            treatment_parts = patient["treatment"].lower().split()
            treatment_matches = sum(1 for part in treatment_parts if len(part) > 4 and part in message_lower)
            if treatment_matches > 0:
                score += treatment_matches
            
            # Check for medication mentions
            medication_lower = patient["medications"].lower()
            # Extract medication names (assuming they're separated by commas)
            medication_parts = [med.strip() for med in medication_lower.split(',')]
            medication_matches = sum(1 for med in medication_parts if med in message_lower)
            if medication_matches > 0:
                score += medication_matches * 2
            
            # If we have any match score, add to potential matches
            if score > 0:
                matched_patients.append(patient)
                match_scores.append(score)
        
        # If we have matches, return the one with highest score
        if matched_patients:
            best_match_index = match_scores.index(max(match_scores))
            # Only return if score is sufficiently high to avoid false positives
            if match_scores[best_match_index] >= 3:
                return matched_patients[best_match_index]
        
        return None
    
    async def generate_response(self, message: str, user_id: str = "default_user") -> Tuple[str, Optional[Dict[str, Any]]]:
        """
        Generate a response to the user's message with language detection and conversation memory
        
        Args:
            message: User's message
            user_id: Unique identifier for the user (for conversation history)
            
        Returns:
            Tuple[str, Optional[Dict]]: Response text and patient record if applicable
        """
        try:
            # Detect language
            language_code, language_name = await self.translator.detect_language(message)
            logger.debug(f"Detected language: {language_name} ({language_code})")
            
            # Check if this is a patient data query
            patient_data = self._detect_patient_query(message)
            
            # Create or retrieve conversation history for this user
            if user_id not in self.conversation_history:
                self.conversation_history[user_id] = {
                    "messages": [],
                    "patient_context": None,
                    "language": {"code": language_code, "name": language_name}
                }
            
            user_history = self.conversation_history[user_id]
            
            # Update the user's preferred language
            user_history["language"] = {"code": language_code, "name": language_name}
            
            # If we found patient data, store it in the conversation context
            if patient_data:
                user_history["patient_context"] = patient_data
            
            # Get previously referenced patient context if available and no new patient was found
            referenced_patient = patient_data or user_history.get("patient_context")
            
            # Add additional context and examples to improve intelligence
            medical_context = self._get_additional_context(message, referenced_patient)
            
            # Prepare chat history for the model with the system prompt in the user's language
            messages = [
                {"role": "system", "content": self._create_system_prompt(
                    language_code=language_code, 
                    language_name=language_name
                )},
            ]
            
            # Add the context if available
            if medical_context:
                messages.append({"role": "system", "content": medical_context})
            
            # Add the conversation history - limited to last 3 exchanges for context
            history_limit = 3
            history_messages = user_history["messages"][-history_limit*2:]  # Get last N exchanges (2 messages each)
            
            # Add the conversation history if we have any
            if history_messages:
                for prev_msg in history_messages:
                    messages.append(prev_msg)
            
            # Add the user message
            messages.append({"role": "user", "content": message})
            
            # Store the user message in history
            user_history["messages"].append({"role": "user", "content": message})
            
            # Generate response based on selected provider
            if self.model_provider == "anthropic" and self.anthropic_client:
                # Use Anthropic API if selected and available
                try:
                    # Convert messages to Anthropic format
                    anthropic_messages = []
                    system_messages = []
                    
                    for msg in messages:
                        if msg["role"] == "system":
                            system_messages.append(msg["content"])
                        else:
                            anthropic_messages.append({
                                "role": msg["role"],
                                "content": msg["content"]
                            })
                    
                    # Create the system prompt by combining all system messages
                    system_prompt = "\n\n".join(system_messages)
                    
                    # Create the chat completion request with Claude
                    # the newest Anthropic model is "claude-3-5-sonnet-20241022" which was released October 22, 2024
                    chat_completion = self.anthropic_client.messages.create(
                        model=self.anthropic_model,
                        system=system_prompt,
                        messages=anthropic_messages,
                        temperature=0.7,
                        max_tokens=1500
                    )
                    
                    # Extract the response text
                    response_text = chat_completion.content[0].text
                    
                except Exception as e:
                    logger.error(f"Error with Anthropic API: {str(e)}")
                    # Fall back to Groq if Anthropic fails
                    logger.info("Falling back to Groq API due to Anthropic error")
                    
                    # Create the chat completion request with Groq as fallback
                    chat_completion = self.groq_client.chat.completions.create(
                        model=self.groq_model,
                        messages=messages,
                        temperature=0.7,
                        max_tokens=1500,
                        top_p=0.95,
                        frequency_penalty=0.2,
                        presence_penalty=0.2
                    )
                    response_text = chat_completion.choices[0].message.content
            else:
                # Use Groq API
                chat_completion = self.groq_client.chat.completions.create(
                    model=self.groq_model,
                    messages=messages,
                    temperature=0.7,  # Slightly higher temperature for more creative responses
                    max_tokens=1500,  # Increased token limit for more detailed responses
                    top_p=0.95,       # Diversity parameter
                    frequency_penalty=0.2,  # Reduce repetition
                    presence_penalty=0.2    # Encourage diverse topics
                )
                # Extract the response text
                response_text = chat_completion.choices[0].message.content
            
            # Store the assistant response in history
            user_history["messages"].append({"role": "assistant", "content": response_text})
            
            # Limit history size to prevent unlimited growth
            max_history = 20  # Max 10 exchanges
            if len(user_history["messages"]) > max_history:
                user_history["messages"] = user_history["messages"][-max_history:]
            
            logger.debug(f"Generated response for message: {message[:30]}...")
            return response_text, patient_data or referenced_patient
            
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            return "I'm sorry, I encountered an error while processing your request. Please try again.", None
