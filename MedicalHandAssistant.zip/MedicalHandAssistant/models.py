from app import db
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import json

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # One-to-one relationship with HandData
    hand_data = db.relationship('HandData', backref='user', uselist=False)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class HandData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    hand_landmarks = db.Column(db.Text, nullable=False)  # Store JSON string of hand landmarks
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_landmarks(self, landmarks_data):
        """Store landmarks data as JSON string"""
        self.hand_landmarks = json.dumps(landmarks_data)
    
    def get_landmarks(self):
        """Get landmarks data as Python object"""
        return json.loads(self.hand_landmarks)

class PatientRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.String(64), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(20), nullable=False)
    condition = db.Column(db.String(128), nullable=False)
    treatment = db.Column(db.Text, nullable=False)
    medications = db.Column(db.Text, nullable=False)
    notes = db.Column(db.Text)
    bill_amount = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'patient_id': self.patient_id,
            'name': self.name,
            'age': self.age,
            'gender': self.gender,
            'condition': self.condition,
            'treatment': self.treatment,
            'medications': self.medications,
            'notes': self.notes,
            'bill_amount': self.bill_amount
        }
