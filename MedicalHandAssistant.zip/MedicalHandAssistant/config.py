import os

class Config:
    # Groq API key
    GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "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")
    
    # Anthropic API key
    ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "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")
    
    # Hand recognition settings
    HAND_SIMILARITY_THRESHOLD = 0.85  # Threshold for considering hands matching
    
    # Chat model settings
    CHAT_MODEL = "llama3-70b-8192"  # Default Groq model
    ANTHROPIC_MODEL = "claude-3-5-sonnet-20241022"  # Latest Anthropic model
    
    # Model provider selection (can be 'groq' or 'anthropic')
    MODEL_PROVIDER = os.environ.get("MODEL_PROVIDER", "anthropic")
    
    # Sample patient records (for demonstration)
    SAMPLE_PATIENTS = [
        {
            "patient_id": "P001",
            "name": "John Doe",
            "age": 42,
            "gender": "Male",
            "condition": "Hypertension",
            "treatment": "Lifestyle changes, regular monitoring",
            "medications": "Lisinopril 10mg daily",
            "notes": "Patient needs to reduce sodium intake and increase physical activity",
            "bill_amount": 150.00
        },
        {
            "patient_id": "P002",
            "name": "Jane Smith",
            "age": 35,
            "gender": "Female",
            "condition": "Type 2 Diabetes",
            "treatment": "Diet control, regular monitoring of blood glucose",
            "medications": "Metformin 500mg twice daily",
            "notes": "Patient has shown improvement with medication adherence",
            "bill_amount": 220.50
        },
        {
            "patient_id": "P003",
            "name": "Michael Johnson",
            "age": 58,
            "gender": "Male",
            "condition": "Osteoarthritis",
            "treatment": "Physical therapy, pain management",
            "medications": "Acetaminophen 500mg as needed, Glucosamine supplement",
            "notes": "Patient reports improvement in mobility after therapy sessions",
            "bill_amount": 345.75
        },
        {
            "patient_id": "P004",
            "name": "Emily Chen",
            "age": 29,
            "gender": "Female",
            "condition": "Asthma",
            "treatment": "Inhaler therapy, avoid triggers",
            "medications": "Albuterol inhaler as needed, Fluticasone 110mcg daily",
            "notes": "Patient has reduced emergency visits significantly this year",
            "bill_amount": 189.25
        }
    ]
