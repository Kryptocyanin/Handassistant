/**
 * Welcome Screen Animation for Ana Medical Assistant
 * 
 * This script handles the animated welcome screen that introduces
 * Ana to the user when they first access the chat interface.
 */
class WelcomeScreen {
  constructor() {
    this.welcomeOverlay = null;
    this.enterButton = null;
    this.hasBeenShown = this.checkIfShown();
  }

  /**
   * Check if welcome screen has been shown in this session
   * @returns {boolean} Whether the welcome screen has been shown
   */
  checkIfShown() {
    return sessionStorage.getItem('anaWelcomeShown') === 'true';
  }

  /**
   * Mark welcome screen as shown in the current session
   */
  markAsShown() {
    sessionStorage.setItem('anaWelcomeShown', 'true');
  }

  /**
   * Create the welcome screen overlay and append it to the body
   */
  createWelcomeScreen() {
    // Create the welcome overlay element
    this.welcomeOverlay = document.createElement('div');
    this.welcomeOverlay.className = 'welcome-overlay';
    
    // Set the content of the welcome overlay
    this.welcomeOverlay.innerHTML = `
      <div class="welcome-content">
        <div class="welcome-logo">
          <i class="fas fa-robot"></i>
        </div>
        
        <h1 class="welcome-title">Meet Ana</h1>
        <p class="welcome-subtitle">Your Intelligent Medical Assistant</p>
        
        <div class="welcome-text">
          <span class="typewriter-text">Hello! I'm Ana, your personal medical assistant. I can provide medical information, analyze patient data, and communicate in multiple languages.</span>
        </div>
        
        <div class="welcome-features">
          <div class="feature-item">
            <i class="fas fa-language"></i>
            <span>Multilingual</span>
          </div>
          <div class="feature-item">
            <i class="fas fa-user-md"></i>
            <span>Medical Expertise</span>
          </div>
          <div class="feature-item">
            <i class="fas fa-brain"></i>
            <span>AI-Powered</span>
          </div>
          <div class="feature-item">
            <i class="fas fa-memory"></i>
            <span>Contextual Memory</span>
          </div>
        </div>
        
        <div class="welcome-footer">
          <button class="enter-button">
            <i class="fas fa-arrow-right me-2"></i> Start Chatting
          </button>
        </div>
      </div>
    `;
    
    // Append the welcome overlay to the body
    document.body.appendChild(this.welcomeOverlay);
    
    // Get the enter button
    this.enterButton = this.welcomeOverlay.querySelector('.enter-button');
    
    // Add event listener to enter button
    this.enterButton.addEventListener('click', () => {
      this.closeWelcomeScreen();
    });
  }

  /**
   * Close the welcome screen with a fade-out animation
   */
  closeWelcomeScreen() {
    // Add the fade-out class to the welcome overlay
    this.welcomeOverlay.classList.add('fade-out');
    
    // Remove the welcome overlay after the animation completes
    setTimeout(() => {
      this.welcomeOverlay.remove();
      this.markAsShown();
    }, 800); // Match the duration of the fadeOut animation
  }

  /**
   * Show the welcome screen if it hasn't been shown in this session
   */
  show() {
    if (!this.hasBeenShown) {
      this.createWelcomeScreen();
    }
  }
}

// Initialize and export for use in other modules
window.WelcomeScreen = WelcomeScreen;