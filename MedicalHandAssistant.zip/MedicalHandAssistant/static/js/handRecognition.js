// Hand Recognition Module
class HandRecognition {
  constructor(videoElement, canvasElement) {
    this.video = videoElement;
    this.canvas = canvasElement;
    this.ctx = this.canvas.getContext('2d');
    this.handLandmarks = [];
    this.isCapturing = false;
    this.isHandVisible = false;
    this.captureTimeout = null;
    this.videoStream = null;
    
    // MediaPipe Hands setup
    this.hands = null;
    this.results = null;
  }

  async initialize() {
    try {
      // Access user's webcam
      this.videoStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" }
      });
      this.video.srcObject = this.videoStream;
      
      // Initialize MediaPipe Hands with CDN files
      this.hands = new window.Hands({
        locateFile: (file) => {
          // Fall back to CDN if local files aren't loading
          return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`;
        }
      });
      
      this.hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
      });
      
      this.hands.onResults((results) => {
        this.results = results;
        this.drawResults();
        this.isHandVisible = results.multiHandLandmarks.length > 0;
        
        if (this.isCapturing && this.isHandVisible) {
          // Store landmarks if we're capturing and a hand is visible
          this.handLandmarks = results.multiHandLandmarks[0];
        }
      });
      
      // Start MediaPipe processing
      const camera = new window.Camera(this.video, {
        onFrame: async () => {
          await this.hands.send({image: this.video});
        }
      });
      camera.start();
      
      return true;
    } catch (error) {
      console.error('Error initializing hand recognition:', error);
      return false;
    }
  }

  drawResults() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.save();
    
    // Draw landmarks and connections if hand is detected
    if (this.results && this.results.multiHandLandmarks.length > 0) {
      for (const landmarks of this.results.multiHandLandmarks) {
        // Draw landmarks
        this.ctx.fillStyle = '#00FF00';
        for (const landmark of landmarks) {
          const x = landmark.x * this.canvas.width;
          const y = landmark.y * this.canvas.height;
          this.ctx.beginPath();
          this.ctx.arc(x, y, 5, 0, 2 * Math.PI);
          this.ctx.fill();
        }
        
        // Draw connections
        this.ctx.strokeStyle = '#00FF00';
        this.ctx.lineWidth = 2;
        this.drawConnections(landmarks);
      }
    }
    
    this.ctx.restore();
  }
  
  drawConnections(landmarks) {
    // Define connections between landmarks
    const connections = [
      // Thumb
      [0, 1], [1, 2], [2, 3], [3, 4],
      // Index finger
      [0, 5], [5, 6], [6, 7], [7, 8],
      // Middle finger
      [0, 9], [9, 10], [10, 11], [11, 12],
      // Ring finger
      [0, 13], [13, 14], [14, 15], [15, 16],
      // Pinky
      [0, 17], [17, 18], [18, 19], [19, 20],
      // Palm
      [0, 5], [5, 9], [9, 13], [13, 17]
    ];
    
    for (const [i, j] of connections) {
      const start = landmarks[i];
      const end = landmarks[j];
      
      if (start && end) {
        this.ctx.beginPath();
        this.ctx.moveTo(start.x * this.canvas.width, start.y * this.canvas.height);
        this.ctx.lineTo(end.x * this.canvas.width, end.y * this.canvas.height);
        this.ctx.stroke();
      }
    }
  }

  startCapture() {
    this.isCapturing = true;
    // Auto-capture after 3 seconds if hand is visible
    this.captureTimeout = setTimeout(() => {
      if (this.isHandVisible) {
        this.captureHand();
      } else {
        // If hand is not visible, keep trying
        this.stopCapture();
        alert('No hand detected. Please try again with your hand clearly visible.');
      }
    }, 3000);
  }
  
  captureHand() {
    if (!this.isHandVisible) {
      alert('No hand detected. Please make sure your hand is visible.');
      return null;
    }
    
    // Capture current hand landmarks and return a copy
    return JSON.parse(JSON.stringify(this.handLandmarks));
  }
  
  stopCapture() {
    this.isCapturing = false;
    if (this.captureTimeout) {
      clearTimeout(this.captureTimeout);
      this.captureTimeout = null;
    }
  }
  
  cleanup() {
    this.stopCapture();
    if (this.videoStream) {
      this.videoStream.getTracks().forEach(track => track.stop());
    }
    if (this.hands) {
      this.hands.close();
    }
  }
  
  // Calculate similarity between current hand pose and stored pose with enhanced algorithm
  calculateSimilarity(storedLandmarks) {
    if (!this.isHandVisible || !storedLandmarks) {
      return 0;
    }
    
    // Improved algorithm with weighted landmarks and finger position analysis
    const numLandmarks = this.handLandmarks.length;
    if (numLandmarks !== storedLandmarks.length) {
      console.error('Landmark count mismatch');
      return 0;
    }
    
    // Define landmark weights - emphasize fingertips and wrist (key points)
    const landmarkWeights = Array(numLandmarks).fill(1.0);
    // Wrist point (anchor)
    landmarkWeights[0] = 2.0;
    // Fingertips (most important for gesture recognition)
    [4, 8, 12, 16, 20].forEach(i => landmarkWeights[i] = 2.5);
    // Finger base points (important for hand shape)
    [5, 9, 13, 17].forEach(i => landmarkWeights[i] = 1.8);
    
    // 1. Calculate relative distances (finger position relative to wrist)
    let relativeDistanceScore = 0;
    let maxRelativeDistancePossible = 0;
    
    // Get wrist position in both landmarks
    const currentWrist = this.handLandmarks[0];
    const storedWrist = storedLandmarks[0];
    
    for (let i = 1; i < numLandmarks; i++) {
      const weight = landmarkWeights[i];
      maxRelativeDistancePossible += weight;
      
      // Calculate relative position vectors (from wrist to point)
      const currentRelativeX = this.handLandmarks[i].x - currentWrist.x;
      const currentRelativeY = this.handLandmarks[i].y - currentWrist.y;
      const currentRelativeZ = this.handLandmarks[i].z - currentWrist.z;
      
      const storedRelativeX = storedLandmarks[i].x - storedWrist.x;
      const storedRelativeY = storedLandmarks[i].y - storedWrist.y;
      const storedRelativeZ = storedLandmarks[i].z - storedWrist.z;
      
      // Calculate similarity of the relative vectors (dot product normalized)
      const dotProduct = (currentRelativeX * storedRelativeX) +
                         (currentRelativeY * storedRelativeY) +
                         (currentRelativeZ * storedRelativeZ);
      
      const currentMagnitude = Math.sqrt(
        Math.pow(currentRelativeX, 2) +
        Math.pow(currentRelativeY, 2) +
        Math.pow(currentRelativeZ, 2)
      );
      
      const storedMagnitude = Math.sqrt(
        Math.pow(storedRelativeX, 2) +
        Math.pow(storedRelativeY, 2) +
        Math.pow(storedRelativeZ, 2)
      );
      
      // Avoid division by zero
      if (currentMagnitude > 0 && storedMagnitude > 0) {
        // Cosine similarity (ranges from -1 to 1, where 1 is identical)
        const cosineSimilarity = dotProduct / (currentMagnitude * storedMagnitude);
        // Convert to 0-1 range and apply weight
        const pointSimilarity = ((cosineSimilarity + 1) / 2) * weight;
        relativeDistanceScore += pointSimilarity;
      }
    }
    
    // 2. Calculate finger bend similarity
    // Analyze the bending of each finger using the angles between segments
    let fingerBendScore = 0;
    let maxFingerBendPossible = 0;
    
    // For each finger
    const fingerJoints = [
      [0, 1, 2, 3, 4],     // Thumb
      [0, 5, 6, 7, 8],     // Index
      [0, 9, 10, 11, 12],  // Middle
      [0, 13, 14, 15, 16], // Ring
      [0, 17, 18, 19, 20]  // Pinky
    ];
    
    fingerJoints.forEach(finger => {
      // Calculate bend angle at each joint
      for (let j = 1; j < finger.length - 1; j++) {
        const p1 = finger[j-1];
        const p2 = finger[j];
        const p3 = finger[j+1];
        
        // Get the points
        const currentP1 = this.handLandmarks[p1];
        const currentP2 = this.handLandmarks[p2];
        const currentP3 = this.handLandmarks[p3];
        
        const storedP1 = storedLandmarks[p1];
        const storedP2 = storedLandmarks[p2];
        const storedP3 = storedLandmarks[p3];
        
        // Calculate vectors for the finger segments
        const currentV1 = {
          x: currentP1.x - currentP2.x,
          y: currentP1.y - currentP2.y,
          z: currentP1.z - currentP2.z
        };
        
        const currentV2 = {
          x: currentP3.x - currentP2.x,
          y: currentP3.y - currentP2.y,
          z: currentP3.z - currentP2.z
        };
        
        const storedV1 = {
          x: storedP1.x - storedP2.x,
          y: storedP1.y - storedP2.y,
          z: storedP1.z - storedP2.z
        };
        
        const storedV2 = {
          x: storedP3.x - storedP2.x,
          y: storedP3.y - storedP2.y,
          z: storedP3.z - storedP2.z
        };
        
        // Calculate dot products
        const currentDot = currentV1.x * currentV2.x + currentV1.y * currentV2.y + currentV1.z * currentV2.z;
        const storedDot = storedV1.x * storedV2.x + storedV1.y * storedV2.y + storedV1.z * storedV2.z;
        
        // Calculate magnitudes
        const currentMag1 = Math.sqrt(currentV1.x * currentV1.x + currentV1.y * currentV1.y + currentV1.z * currentV1.z);
        const currentMag2 = Math.sqrt(currentV2.x * currentV2.x + currentV2.y * currentV2.y + currentV2.z * currentV2.z);
        const storedMag1 = Math.sqrt(storedV1.x * storedV1.x + storedV1.y * storedV1.y + storedV1.z * storedV1.z);
        const storedMag2 = Math.sqrt(storedV2.x * storedV2.x + storedV2.y * storedV2.y + storedV2.z * storedV2.z);
        
        // Calculate angles (in radians)
        const currentAngle = Math.acos(currentDot / (currentMag1 * currentMag2));
        const storedAngle = Math.acos(storedDot / (storedMag1 * storedMag2));
        
        // Compare the angles
        const angleDifference = Math.abs(currentAngle - storedAngle);
        // Convert to similarity score (0-1)
        const angleSimilarity = Math.max(0, 1 - angleDifference / Math.PI);
        
        // Weight is higher for fingertips
        const weight = (j === finger.length - 2) ? 2.0 : 1.0;
        maxFingerBendPossible += weight;
        fingerBendScore += angleSimilarity * weight;
      }
    });
    
    // 3. Combine the scores with appropriate weights
    const relativePositionWeight = 0.6;
    const fingerBendWeight = 0.4;
    
    const relativePositionNormalized = relativeDistanceScore / maxRelativeDistancePossible;
    const fingerBendNormalized = fingerBendScore / maxFingerBendPossible;
    
    const combinedSimilarity = 
      (relativePositionNormalized * relativePositionWeight) +
      (fingerBendNormalized * fingerBendWeight);
    
    // Adjust the threshold for better accuracy (more strict or more lenient)
    // Apply a non-linear transformation to make the similarity more discriminative
    const finalSimilarity = Math.pow(combinedSimilarity, 0.75); // This makes higher similarities more pronounced
    
    console.log('Hand similarity score:', finalSimilarity.toFixed(4), 
                'Position:', relativePositionNormalized.toFixed(4), 
                'Finger bend:', fingerBendNormalized.toFixed(4));
    
    return finalSimilarity;
  }
}

// Export for use in other modules
window.HandRecognition = HandRecognition;
