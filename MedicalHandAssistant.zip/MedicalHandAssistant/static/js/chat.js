// Chat functionality for Ana - the medical chatbot
class AnaMedicalAssistant {
  constructor(messagesContainer, messageInput, sendButton) {
    this.messagesContainer = messagesContainer;
    this.messageInput = messageInput;
    this.sendButton = sendButton;
    this.isProcessing = false;
    this.lastResponse = ''; // Store the last response for translation
  }

  initialize() {
    // Setup event listeners
    this.sendButton.addEventListener('click', () => this.sendMessage());
    this.messageInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this.sendMessage();
      }
    });
  }

  sendMessage() {
    const message = this.messageInput.value.trim();
    if (message === '' || this.isProcessing) return;
    
    // Add user message to the chat
    this.addMessage(message, 'user');
    this.messageInput.value = '';
    
    // Check if message is a translation request
    if (this.isTranslationRequest(message)) {
      this.handleTranslation(message);
    } else {
      // Send message to server for processing
      this.getChatbotResponse(message);
    }
  }

  addMessage(content, sender, isLoading = false) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', `${sender}-message`);
    
    if (isLoading) {
      messageElement.innerHTML = '<div class="loading-spinner"></div> Thinking...';
      messageElement.setAttribute('data-loading', 'true');
    } else {
      // Process content for different types
      if (typeof content === 'object' && content.type === 'patient-data') {
        // Create a patient card
        messageElement.innerHTML = this.createPatientCard(content.data);
      } else {
        // Regular text message, no special formatting
        messageElement.innerText = content;
      }
    }
    
    this.messagesContainer.appendChild(messageElement);
    this.scrollToBottom();
    
    return messageElement;
  }

  createPatientCard(patientData) {
    return `
      <div class="patient-card card">
        <div class="card-header bg-success text-white">
          <h5 class="mb-0">Patient: ${patientData.name} (ID: ${patientData.patient_id})</h5>
        </div>
        <div class="card-body">
          <p><strong>Age:</strong> ${patientData.age}</p>
          <p><strong>Gender:</strong> ${patientData.gender}</p>
          <p><strong>Condition:</strong> ${patientData.condition}</p>
          <p><strong>Treatment:</strong> ${patientData.treatment}</p>
          <p><strong>Medications:</strong> ${patientData.medications}</p>
          <p><strong>Notes:</strong> ${patientData.notes || 'None'}</p>
          <p><strong>Bill Amount:</strong> $${patientData.bill_amount.toFixed(2)}</p>
        </div>
      </div>
    `;
  }

  updateLoadingMessage(element, content) {
    if (element && element.getAttribute('data-loading') === 'true') {
      // If content is an object (patient data), create a patient card
      if (typeof content === 'object' && content.type === 'patient-data') {
        element.innerHTML = this.createPatientCard(content.data);
      } else {
        // Regular text message without disclaimer
        element.innerText = content;
      }
      element.removeAttribute('data-loading');
    }
  }

  getChatbotResponse(message) {
    this.isProcessing = true;
    const loadingElement = this.addMessage('', 'bot', true);
    
    fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: message })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      if (data.error) {
        throw new Error(data.error);
      }
      
      if (!data.response) {
        throw new Error('No response received from the server');
      }
      
      this.lastResponse = data.response;
      this.updateLoadingMessage(loadingElement, data.response);
      
      // If there's patient data to display
      if (data.patient_data) {
        this.addMessage({ type: 'patient-data', data: data.patient_data }, 'bot');
      }
    })
    .catch(error => {
      console.error('Error fetching chatbot response:', error);
      this.updateLoadingMessage(loadingElement, 'Sorry, I encountered an error. Please try again.');
    })
    .finally(() => {
      this.isProcessing = false;
    });
  }

  isTranslationRequest(message) {
    // Check if message starts with "translate to" or similar
    return /^translate\s+to\s+/i.test(message);
  }

  handleTranslation(message) {
    if (!this.lastResponse) {
      this.addMessage('There is no previous message to translate.', 'bot');
      return;
    }
    
    // Extract the target language
    const match = message.match(/^translate\s+to\s+(.+)$/i);
    if (!match || !match[1]) {
      this.addMessage('Please specify a language to translate to.', 'bot');
      return;
    }
    
    const targetLanguage = match[1].trim();
    this.isProcessing = true;
    const loadingElement = this.addMessage('', 'bot', true);
    
    fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        text: this.lastResponse,
        target_language: targetLanguage 
      })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      if (data.error) {
        throw new Error(data.error);
      }
      
      if (!data.translated_text) {
        throw new Error('No translation received from the server');
      }
      
      this.updateLoadingMessage(loadingElement, data.translated_text);
    })
    .catch(error => {
      console.error('Error translating text:', error);
      this.updateLoadingMessage(loadingElement, 'Sorry, I could not translate the message. Please try again.');
    })
    .finally(() => {
      this.isProcessing = false;
    });
  }

  scrollToBottom() {
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  }
}

// Export for use in other modules
window.MedicalChatbot = AnaMedicalAssistant; // Keep the old name for compatibility
window.AnaMedicalAssistant = AnaMedicalAssistant;
