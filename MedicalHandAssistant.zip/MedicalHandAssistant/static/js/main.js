// Main JavaScript file for initializing components

document.addEventListener('DOMContentLoaded', function() {
  // Initialize tooltips and popovers
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  })
  
  const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
  const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl)
  })

  // Initialize Hand Registration if on that page
  if (document.getElementById('hand-registration-page')) {
    initializeHandRegistration();
  }
  
  // Initialize Hand Verification if on that page
  if (document.getElementById('hand-verification-page')) {
    initializeHandVerification();
  }
  
  // Initialize Chat Interface if on that page
  if (document.getElementById('chat-page')) {
    initializeChatInterface();
  }
});

function initializeHandRegistration() {
  const video = document.getElementById('webcam');
  const canvas = document.getElementById('canvas-overlay');
  const captureBtn = document.getElementById('capture-btn');
  const submitBtn = document.getElementById('submit-btn');
  const statusElement = document.getElementById('status');
  let handLandmarks = null;
  
  // Resize canvas to match video dimensions
  canvas.width = video.clientWidth;
  canvas.height = video.clientHeight;
  
  // Create hand recognition instance
  const handRecognition = new HandRecognition(video, canvas);
  
  // Create progress container
  const progressContainer = document.createElement('div');
  progressContainer.className = 'progress mb-3 mt-3';
  progressContainer.innerHTML = '<div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>';
  
  // Create confirmation container
  const confirmationContainer = document.createElement('div');
  confirmationContainer.className = 'confirmation-container mt-3 d-none';
  
  // Insert elements after status
  statusElement.after(progressContainer);
  progressContainer.after(confirmationContainer);
  
  const progressBar = progressContainer.querySelector('.progress-bar');
  
  handRecognition.initialize().then(success => {
    if (!success) {
      statusElement.textContent = 'Failed to initialize camera. Please make sure your device has a camera and you have granted permission.';
      statusElement.classList.add('text-danger');
      return;
    }
    
    // Start automatic capture process
    startAutomaticCapture();
  });
  
  function startAutomaticCapture() {
    // Hide manual capture button during automatic capture
    captureBtn.style.display = 'none';
    
    // Update status and progress
    statusElement.textContent = 'Detecting your hand... Please hold your hand up in front of the camera.';
    progressBar.style.width = '25%';
    
    // Start waiting animation
    let dots = '';
    const waitingInterval = setInterval(() => {
      dots = dots.length >= 3 ? '' : dots + '.';
      statusElement.textContent = 'Detecting your hand' + dots;
    }, 500);
    
    // Start capture after a short delay
    setTimeout(() => {
      handRecognition.startCapture();
      progressBar.style.width = '50%';
      
      // Check for hand every second for up to 5 seconds
      let checkAttempts = 0;
      const maxCheckAttempts = 5;
      
      const checkInterval = setInterval(() => {
        checkAttempts++;
        
        // Try to capture the hand
        const currentLandmarks = handRecognition.captureHand();
        
        if (currentLandmarks) {
          // Success - hand detected
          clearInterval(waitingInterval);
          clearInterval(checkInterval);
          handRecognition.stopCapture();
          
          // Save the landmarks
          handLandmarks = currentLandmarks;
          document.getElementById('hand-data').value = JSON.stringify(handLandmarks);
          
          // Show success feedback
          progressBar.style.width = '75%';
          progressBar.classList.add('bg-success');
          statusElement.textContent = 'Hand detected successfully!';
          statusElement.classList.remove('text-danger');
          statusElement.classList.add('text-success');
          
          // Show confirmation UI
          showConfirmation();
        } 
        else if (checkAttempts >= maxCheckAttempts) {
          // Failed after max attempts
          clearInterval(waitingInterval);
          clearInterval(checkInterval);
          handRecognition.stopCapture();
          
          // Show failure feedback
          progressBar.style.width = '30%';
          progressBar.classList.add('bg-danger');
          statusElement.textContent = 'Automatic hand detection failed. Please try manually.';
          statusElement.classList.add('text-danger');
          
          // Show manual capture button
          captureBtn.style.display = 'block';
          captureBtn.disabled = false;
        }
      }, 1000);
    }, 2000);
  }
  
  function showConfirmation() {
    // Update progress
    progressBar.style.width = '90%';
    
    // Show confirmation UI
    confirmationContainer.classList.remove('d-none');
    confirmationContainer.innerHTML = `
      <div class="card border-success mb-3">
        <div class="card-header bg-success text-white">
          <h5 class="mb-0"><i class="fas fa-check-circle me-2"></i>Hand Captured Successfully</h5>
        </div>
        <div class="card-body text-center">
          <p>Your hand position has been successfully recorded.</p>
          <p>Is this the position you want to use for verification?</p>
          <div class="d-flex justify-content-center gap-3">
            <button id="confirm-btn" class="btn btn-success">
              <i class="fas fa-check me-2"></i>Yes, Confirm
            </button>
            <button id="retry-btn" class="btn btn-secondary">
              <i class="fas fa-redo me-2"></i>Try Again
            </button>
          </div>
        </div>
      </div>
    `;
    
    // Add event listeners for confirmation buttons
    document.getElementById('confirm-btn').addEventListener('click', () => {
      // Complete progress
      progressBar.style.width = '100%';
      
      // Show success message
      statusElement.textContent = 'Hand registered successfully! Proceeding to verification...';
      
      // Auto-submit the form
      submitBtn.disabled = false;
      submitBtn.click();
    });
    
    document.getElementById('retry-btn').addEventListener('click', () => {
      // Reset UI elements
      confirmationContainer.classList.add('d-none');
      progressBar.style.width = '0%';
      progressBar.classList.remove('bg-success');
      statusElement.classList.remove('text-success');
      
      // Start the process again
      startAutomaticCapture();
    });
  }
  
  // Manual capture button as fallback
  captureBtn.addEventListener('click', function() {
    statusElement.textContent = 'Hold your hand still for 3 seconds...';
    captureBtn.disabled = true;
    progressBar.style.width = '50%';
    
    // Start capture mode
    handRecognition.startCapture();
    
    // After 3 seconds, check if capture was successful
    setTimeout(() => {
      const landmarks = handRecognition.captureHand();
      handRecognition.stopCapture();
      
      if (landmarks) {
        // Save landmarks
        handLandmarks = landmarks;
        document.getElementById('hand-data').value = JSON.stringify(landmarks);
        
        // Show success feedback
        progressBar.style.width = '75%';
        progressBar.classList.add('bg-success');
        statusElement.textContent = 'Hand captured successfully!';
        statusElement.classList.remove('text-danger');
        statusElement.classList.add('text-success');
        
        // Show confirmation UI
        showConfirmation();
      } else {
        // Show failure feedback
        statusElement.textContent = 'Failed to capture hand. Please try again.';
        statusElement.classList.add('text-danger');
        captureBtn.disabled = false;
        progressBar.style.width = '25%';
        progressBar.classList.add('bg-danger');
      }
    }, 3000);
  });
  
  // Clean up when leaving the page
  window.addEventListener('beforeunload', () => {
    handRecognition.cleanup();
  });
}

function initializeHandVerification() {
  const video = document.getElementById('webcam');
  const canvas = document.getElementById('canvas-overlay');
  const verifyBtn = document.getElementById('verify-btn');
  const statusElement = document.getElementById('status');
  const storedDataElement = document.getElementById('stored-hand-data');
  
  // Resize canvas to match video dimensions
  canvas.width = video.clientWidth;
  canvas.height = video.clientHeight;
  
  // Get stored hand data - handle potential parsing errors
  let storedHandData;
  try {
    // Check if data is already a JSON object or needs parsing
    const rawValue = storedDataElement.value;
    console.log("Raw stored hand data:", rawValue);
    
    // If it's already a string representation of JSON, parse it
    // Otherwise, assume it's already valid JSON
    if (rawValue.trim().startsWith('[') || rawValue.trim().startsWith('{')) {
      storedHandData = JSON.parse(rawValue);
    } else {
      storedHandData = rawValue;
    }

    console.log("Processed stored hand data:", storedHandData);
  } catch (error) {
    console.error('Error parsing hand data:', error);
    statusElement.textContent = 'Error loading stored hand data. Please try logging in again.';
    statusElement.classList.add('text-danger');
    verifyBtn.textContent = 'Return to Login';
    verifyBtn.disabled = false;
    verifyBtn.addEventListener('click', () => {
      window.location.href = '/login';
    });
    return;
  }
  
  // Create feedback containers
  const feedbackContainer = document.createElement('div');
  feedbackContainer.className = 'verification-feedback mt-3';
  statusElement.after(feedbackContainer);
  
  // Create progress bar
  const progressBar = document.createElement('div');
  progressBar.className = 'progress mb-2';
  progressBar.innerHTML = '<div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>';
  feedbackContainer.appendChild(progressBar);
  
  // Create detailed feedback container
  const detailedFeedback = document.createElement('div');
  detailedFeedback.className = 'detailed-feedback small';
  feedbackContainer.appendChild(detailedFeedback);
  
  const progressBarInner = progressBar.querySelector('.progress-bar');
  
  // Create hand recognition instance
  const handRecognition = new HandRecognition(video, canvas);
  
  // Hide verify button to start automatic verification
  verifyBtn.style.display = 'none';
  
  // Initial status update
  statusElement.textContent = 'Initializing camera for hand verification...';
  detailedFeedback.innerHTML = '<div class="step step-init"><i class="fas fa-spinner fa-spin"></i> Initializing camera...</div>';
  
  handRecognition.initialize().then(success => {
    if (!success) {
      statusElement.textContent = 'Failed to initialize camera. Please make sure your device has a camera and you have granted permission.';
      statusElement.classList.add('text-danger');
      detailedFeedback.innerHTML = '<div class="step step-init text-danger"><i class="fas fa-times-circle"></i> Camera initialization failed.</div>';
      // Show manual verification button as fallback
      verifyBtn.style.display = 'block';
      verifyBtn.disabled = false;
      return;
    }
    
    // Camera initialized successfully, start automatic verification
    detailedFeedback.innerHTML = '<div class="step step-init text-success"><i class="fas fa-check-circle"></i> Camera initialized successfully</div>';
    progressBarInner.style.width = '20%';
    
    // Start automatic verification process
    startAutomaticVerification();
  });
  
  function startAutomaticVerification() {
    // Update status and show animation
    statusElement.textContent = 'Please place your hand in the same position as during registration...';
    detailedFeedback.innerHTML += '<div class="step step-1"><i class="fas fa-spinner fa-spin"></i> Waiting for your hand to be detected...</div>';
    progressBarInner.style.width = '30%';
    
    // Waiting animation
    let dots = '';
    const waitingInterval = setInterval(() => {
      dots = dots.length >= 3 ? '' : dots + '.';
      statusElement.textContent = 'Waiting for hand detection' + dots;
    }, 500);
    
    // Start hand detection
    handRecognition.startCapture();
    
    // Check for hand visibility periodically
    let attempts = 0;
    const maxAttempts = 5;
    
    const checkHandInterval = setInterval(() => {
      attempts++;
      
      // If hand is visible, proceed with verification
      if (handRecognition.isHandVisible) {
        clearInterval(checkHandInterval);
        clearInterval(waitingInterval);
        
        // Proceed to capture and verification
        captureAndVerifyHand();
      } 
      else if (attempts >= maxAttempts) {
        // Failed after max attempts, show manual option
        clearInterval(checkHandInterval);
        clearInterval(waitingInterval);
        handRecognition.stopCapture();
        
        statusElement.textContent = 'Automatic hand detection failed. Please click "Verify Identity" to try manually.';
        statusElement.classList.add('text-warning');
        
        detailedFeedback.innerHTML += '<div class="step step-1 text-warning"><i class="fas fa-exclamation-triangle"></i> Hand not detected automatically. Please try manual verification.</div>';
        progressBarInner.style.width = '20%';
        progressBarInner.classList.add('bg-warning');
        
        // Show manual verification button
        verifyBtn.style.display = 'block';
        verifyBtn.disabled = false;
      }
    }, 1000);
  }
  
  function captureAndVerifyHand() {
    statusElement.textContent = 'Hand detected! Analyzing position...';
    detailedFeedback.innerHTML += '<div class="step step-1 text-success"><i class="fas fa-check-circle"></i> Hand detected successfully</div>' +
                                '<div class="step step-2"><i class="fas fa-spinner fa-spin"></i> Capturing and comparing with registered hand...</div>';
    progressBarInner.style.width = '50%';
    
    // Capture current hand landmarks
    setTimeout(() => {
      const currentLandmarks = handRecognition.captureHand();
      
      if (!currentLandmarks) {
        // Failed to capture landmarks
        statusElement.textContent = 'Failed to capture hand details. Please try again.';
        statusElement.classList.add('text-danger');
        
        detailedFeedback.innerHTML += '<div class="step step-2 text-danger"><i class="fas fa-times-circle"></i> Hand capture failed. Please ensure your entire hand is visible.</div>';
        progressBarInner.classList.add('bg-danger');
        
        // Show manual verification button
        verifyBtn.style.display = 'block';
        verifyBtn.disabled = false;
        handRecognition.stopCapture();
        return;
      }
      
      // Success with capture, proceed with similarity calculation
      progressBarInner.style.width = '70%';
      
      // Calculate similarity
      const similarity = handRecognition.calculateSimilarity(storedHandData);
      const similarityPercentage = Math.round(similarity * 100);
      
      // Check if it matches
      const threshold = 0.80;  // Slightly more lenient threshold
      
      if (similarity >= threshold) {
        // Successful verification
        detailedFeedback.innerHTML += `<div class="step step-2 text-success"><i class="fas fa-check-circle"></i> Hand comparison complete - ${similarityPercentage}% match</div>` +
                                     '<div class="step step-3"><i class="fas fa-spinner fa-spin"></i> Finalizing verification...</div>';
        progressBarInner.style.width = '85%';
        
        // Finalize verification
        setTimeout(() => {
          statusElement.textContent = 'Verification successful! Redirecting to chat...';
          statusElement.classList.add('text-success');
          
          detailedFeedback.innerHTML += '<div class="step step-3 text-success"><i class="fas fa-check-circle"></i> Verification complete</div>';
          progressBarInner.style.width = '100%';
          progressBarInner.classList.add('bg-success');
          
          // Add completion animation
          const completeIcon = document.createElement('div');
          completeIcon.className = 'text-center mt-3';
          completeIcon.innerHTML = '<i class="fas fa-shield-alt text-success" style="font-size: 3rem;"></i>' +
                                  '<p class="mt-2">Identity Confirmed</p>';
          feedbackContainer.appendChild(completeIcon);
          
          // Set the current hand data to the hidden input
          document.getElementById('current-hand-data').value = JSON.stringify(currentLandmarks);
          
          // Submit form to proceed with server-side verification
          setTimeout(() => {
            document.getElementById('verification-form').submit();
          }, 1500);
        }, 1000);
      } else {
        // Failed verification
        handRecognition.stopCapture();
        
        // Customize feedback based on similarity level
        let feedbackMessage = '';
        if (similarity < 0.3) {
          feedbackMessage = 'Hand position is very different from your registered hand. Please use the same hand and position as during registration.';
        } else if (similarity < 0.5) {
          feedbackMessage = 'Hand position differs significantly. Try adjusting your hand to match the position used during registration.';
        } else if (similarity < 0.7) {
          feedbackMessage = 'Your hand position is close, but not close enough. Try small adjustments to your fingers and hand angle.';
        } else {
          feedbackMessage = 'Your hand is almost recognized. Try minor adjustments to your finger positions.';
        }
        
        statusElement.textContent = `Verification failed (${similarityPercentage}% match). Please try again.`;
        statusElement.classList.add('text-danger');
        
        detailedFeedback.innerHTML += `<div class="step step-2 text-warning">
          <i class="fas fa-exclamation-triangle"></i> Hand comparison shows ${similarityPercentage}% match (below required 80%)
          <p class="mt-1 small text-muted">${feedbackMessage}</p>
        </div>`;
        
        progressBarInner.classList.add('bg-warning');
        
        // Show manual verification button with retry option
        verifyBtn.style.display = 'block';
        verifyBtn.disabled = false;
        verifyBtn.innerHTML = '<i class="fas fa-redo"></i> Try Again';
      }
    }, 2000);
  }
  
  // Fallback manual verification button handler
  verifyBtn.addEventListener('click', function() {
    // Reset UI elements
    statusElement.classList.remove('text-danger', 'text-success', 'text-warning');
    progressBarInner.style.width = '30%';
    progressBarInner.classList.remove('bg-danger', 'bg-warning', 'bg-success');
    
    // Update status
    statusElement.textContent = 'Analyzing hand position...';
    verifyBtn.disabled = true;
    
    // Reset the detailed feedback
    detailedFeedback.innerHTML = '<div class="step step-1"><i class="fas fa-spinner fa-spin"></i> Capturing hand position...</div>';
    
    // Start capture mode
    handRecognition.startCapture();
    
    // Check for landmarks after 2 seconds
    setTimeout(() => {
      const currentLandmarks = handRecognition.captureHand();
      handRecognition.stopCapture();
      
      if (!currentLandmarks) {
        // Failed to capture hand
        statusElement.textContent = 'Failed to capture hand. Please make sure your hand is clearly visible.';
        statusElement.classList.add('text-danger');
        
        detailedFeedback.innerHTML = '<div class="step step-1 text-danger"><i class="fas fa-times-circle"></i> Hand capture failed. Please ensure good lighting and that your entire hand is visible.</div>';
        progressBarInner.classList.add('bg-danger');
        verifyBtn.disabled = false;
        return;
      }
      
      // Success with capture
      detailedFeedback.innerHTML = '<div class="step step-1 text-success"><i class="fas fa-check-circle"></i> Hand position captured successfully</div>' +
                                 '<div class="step step-2"><i class="fas fa-spinner fa-spin"></i> Comparing with registered hand...</div>';
      progressBarInner.style.width = '60%';
      
      // Calculate similarity
      setTimeout(() => {
        const similarity = handRecognition.calculateSimilarity(storedHandData);
        const similarityPercentage = Math.round(similarity * 100);
        const threshold = 0.80;
        
        if (similarity >= threshold) {
          // Successful verification
          statusElement.textContent = 'Verification successful! Redirecting to chat...';
          statusElement.classList.add('text-success');
          
          detailedFeedback.innerHTML += `<div class="step step-2 text-success"><i class="fas fa-check-circle"></i> Comparison complete - ${similarityPercentage}% match</div>`;
          progressBarInner.style.width = '100%';
          progressBarInner.classList.add('bg-success');
          
          // Set form data and submit
          document.getElementById('current-hand-data').value = JSON.stringify(currentLandmarks);
          setTimeout(() => {
            document.getElementById('verification-form').submit();
          }, 1500);
        } else {
          // Failed verification
          let feedbackMessage = similarity < 0.5 ? 
            'Hand position is very different from your registered hand.' : 
            'Your hand position is close, but not close enough. Try small adjustments.';
          
          statusElement.textContent = `Verification failed (${similarityPercentage}% match). Please try again.`;
          statusElement.classList.add('text-danger');
          
          detailedFeedback.innerHTML += `<div class="step step-2 text-warning">
            <i class="fas fa-exclamation-triangle"></i> Comparison shows ${similarityPercentage}% match (below required 80%)
            <p class="mt-1 small text-muted">${feedbackMessage}</p>
          </div>`;
          
          progressBarInner.classList.add('bg-warning');
          verifyBtn.disabled = false;
        }
      }, 1500);
    }, 2000);
  });
  
  // Clean up when leaving the page
  window.addEventListener('beforeunload', () => {
    handRecognition.cleanup();
  });
}

function initializeChatInterface() {
  const messagesContainer = document.getElementById('messages');
  const messageInput = document.getElementById('message-input');
  const sendButton = document.getElementById('send-button');
  
  const chatbot = new AnaMedicalAssistant(messagesContainer, messageInput, sendButton);
  chatbot.initialize();
  
  // Add welcome message
  chatbot.addMessage('Hello! I\'m Ana, your intelligent medical assistant. How can I help you today?', 'bot');
}
